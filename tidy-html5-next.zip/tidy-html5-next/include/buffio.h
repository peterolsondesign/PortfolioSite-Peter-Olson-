/** @file buffio.h - Deprecated compatibility header. Use tidybuffio.h
**
** @deprecated This compatibility header is deprecated and 
** should be replaced by tidybuffio.h. This header will be removed!
**
*/

#ifdef __GNUC__
#warning "FIXME: Using compatibility tidy header (buffio.h) that will go away! Use tidybuffio.h"
#endif
#ifdef _MSC_VER
#pragma message("WARNING: ** FIXME ** Using compatibility tidy header (buffio.h) that will go away! Use tidybuffio.h")
#endif

#include "tidybuffio.h"


